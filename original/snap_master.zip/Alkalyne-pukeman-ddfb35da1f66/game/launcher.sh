#!/bin/bash
java -jar Pricman.jar
