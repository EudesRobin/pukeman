package Interface;

import pacman.Global;

public class Main {

	public static void main(String[] arg) {
		/* LANCEMENT DU MENU D'ACCEUIL */
		Global.high = new Highscore();
		Global.men = new Menu();

	}
}
