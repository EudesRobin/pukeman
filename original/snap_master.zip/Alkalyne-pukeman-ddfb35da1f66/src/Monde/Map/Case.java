package Monde.Map;

import java.awt.Image;

/**
 * Format classique d'une case
 * 
 * @author Romain BADAMO-BARTHELEMY Christelle BODARD David BUI Alan DAMOTTE
 *         Robin EUDES Ombeline ROSSI
 * 
 */

public abstract class Case {
	public int x, y;

	public Image getImageCase() {
		return null;
	}
}
