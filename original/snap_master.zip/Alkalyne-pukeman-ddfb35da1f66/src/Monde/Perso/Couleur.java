package Monde.Perso;

/**
 * Couleurs des fantômes
 * 
 * @author Romain BADAMO-BARTHELEMY Christelle BODARD David BUI Alan DAMOTTE
 *         Robin EUDES Ombeline ROSSI
 * 
 */

public enum Couleur {
	Rouge, Noir, Vert, Jaune, Blanc, Bleu, Cyan, Orange, Rose;
}
