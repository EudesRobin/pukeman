package Monde.Perso;

/**
 * Enumération des directions possibles
 * 
 * @author Romain BADAMO-BARTHELEMY Christelle BODARD David BUI Alan DAMOTTE
 *         Robin EUDES Ombeline ROSSI
 * 
 */

public enum Direction {
	Haut, Bas, Gauche, Droite, Null;
}
