package pacman;

/**
 * Niveau de difficulté du jeu...
 * 
 * @author Romain BADAMO-BARTHELEMY Christelle BODARD David BUI Alan DAMOTTE
 *         Robin EUDES Ombeline ROSSI
 */

public enum EnumDifficulte {
	FACILE("Facile"), MOYEN("Moyen"), DIFFICILE("Difficile");

	public static String diff;

	private EnumDifficulte(String diff) {
	}

}
